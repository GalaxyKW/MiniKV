#!/usr/bin/env python3
"""Execute a frozen MiniKV comparison once; stop after any failed stage."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PLAN_PATH = ROOT / 'plan.json'


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def main():
    plan = json.loads(PLAN_PATH.read_text())
    execution_path = ROOT / 'execution.json'
    if execution_path.exists():
        raise RuntimeError('existing execution is never restarted or overwritten')
    for identity in plan['frozen_files']:
        if digest(identity['path']) != identity['sha256']:
            raise RuntimeError('frozen file changed: ' + identity['path'])
    execution = {'schema_version': 1, 'status': 'running', 'started_at': now(),
                 'plan_sha256': digest(PLAN_PATH), 'controller_sha256': digest(__file__),
                 'stages': [{**stage, 'status': 'not_executed'} for stage in plan['stages']]}
    save(execution_path, execution)
    child, interrupted = None, None

    def stop(signum, frame):
        nonlocal interrupted
        interrupted = signum
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGTERM)

    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, stop)
    try:
        for stage in execution['stages']:
            if interrupted is not None:
                break
            for identity in plan['frozen_files']:
                if digest(identity['path']) != identity['sha256']:
                    raise RuntimeError('frozen file changed: ' + identity['path'])
            command = [sys.executable, plan['collector'], '--output', str(ROOT / stage['name']),
                       '--engine', plan['engines'][stage['version']],
                       '--gateway', plan['gateway'], '--bench', plan['bench'],
                       *plan['common_args'], *stage['scenario_args']]
            stage.update(status='running', started_at=now(), command=command)
            save(execution_path, execution)
            print('START ' + stage['name'], flush=True)
            with (ROOT / (stage['name'] + '.log')).open('xb') as log:
                if interrupted is not None:
                    stage.update(status='interrupted', finished_at=now())
                    break
                child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                         stdin=subprocess.DEVNULL, start_new_session=True)
                if interrupted is not None:
                    child.send_signal(signal.SIGTERM)
                stage['collector_pid'] = child.pid
                save(execution_path, execution)
                # No observation timeout restarts a stage. Collector bounds each
                # run and owns cleanup of its guarded service processes.
                code = child.wait()
            child = None
            stage.update(status='complete' if code == 0 else 'failed',
                         exit_code=code, finished_at=now())
            save(execution_path, execution)
            print('END ' + stage['name'] + ' exit=' + str(code), flush=True)
            if code != 0:
                break
        execution['status'] = ('interrupted' if interrupted is not None else
                               'complete' if all(s['status'] == 'complete' for s in execution['stages'])
                               else 'failed')
        return 0 if execution['status'] == 'complete' else 1
    except BaseException as error:
        execution.update(status='failed', error=repr(error))
        raise
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=150)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
        execution['finished_at'] = now()
        save(execution_path, execution)


if __name__ == '__main__':
    sys.exit(main())
