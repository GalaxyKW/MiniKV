"""Execute the recorded plan serially; preserve every run and its exit status."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=("pilot", "formal"))
parser.add_argument("--repo", type=Path, default=Path.cwd())
args = parser.parse_args()
root = Path(__file__).resolve().parent
plan = json.loads((root / "PLAN.json").read_text())
phase = root / args.phase
phase.mkdir(exist_ok=False)
stages = plan[args.phase + "_order"]
records = []
for name in stages:
    config = dict(plan["common"], **plan["arms"][name[0]])
    if args.phase == "pilot":
        config["requests"] = plan["pilot_requests"]
    command = [sys.executable, str(args.repo / "benmark/experiment.py"), "--output", str(phase / name)]
    for role, identity in plan["binaries"].items():
        path = Path(identity["path"])
        if hashlib.sha256(path.read_bytes()).hexdigest() != identity["sha256"]:
            raise RuntimeError(role + " binary changed after the plan was recorded")
        command += ["--" + role, str(path)]
    for key, value in config.items():
        command += ["--" + key.replace("_", "-"), str(value)]
    record = {"stage": name, "started_at": datetime.now(timezone.utc).isoformat(), "command": command}
    records.append(record)
    (phase / "execution.json").write_text(json.dumps(records, indent=2) + "\n")
    print("Running " + args.phase + "/" + name, flush=True)
    with (phase / (name + ".log")).open("w") as log:
        result = subprocess.run(command, cwd=args.repo, stdout=log, stderr=subprocess.STDOUT)
    record.update(returncode=result.returncode, finished_at=datetime.now(timezone.utc).isoformat())
    (phase / "execution.json").write_text(json.dumps(records, indent=2) + "\n")
    index = json.loads((phase / name / "index.json").read_text())
    if (result.returncode not in (0, 1) or index["status"] != "complete" or len(index["runs"]) != 2
            or any(run["status"] not in ("ok", "degraded") for run in index["runs"])):
        raise RuntimeError("Incomplete or failed experiment retained at " + str(phase / name))
    for run in index["runs"]:
        metrics = run["metrics"]
        print("  {} {} attempts={}/{} busy={} late={} failures={} offered={:.3f}%".format(
            run["name"], run["status"], metrics["arrival_started"], metrics["arrival_planned"],
            metrics["dropped_busy"], metrics["dropped_late"], metrics["failures"], metrics["offered_success_rate_pct"]), flush=True)
