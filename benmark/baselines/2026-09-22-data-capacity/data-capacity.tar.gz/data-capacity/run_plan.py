#!/usr/bin/env python3
"""Execute the frozen data-capacity comparison once; preserve every stage."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import sys


def utc():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--repository', type=Path, required=True)
    args = parser.parse_args()
    root, repo = args.root.resolve(), args.repository.resolve()
    plan_path = root / 'plan.json'
    plan = json.loads(plan_path.read_text())
    assert not (root / 'execution.json').exists(), 'A started plan must not be restarted'
    sys.path.insert(0, str(repo / 'benmark'))
    from experiment_support import collect_metadata
    for row in plan['binaries'].values():
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == plan['collector_revision']
    state = {'plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
             'started_at': utc(), 'status': 'running', 'stages': []}
    write(root / 'execution.json', state)
    process = None
    signals = {'launching': False, 'cleaning': False, 'pending': None}

    def interrupted(signum, frame):
        if signals['launching'] or signals['cleaning']:
            signals['pending'] = signum
            return
        if process is not None and process.poll() is None:
            process.send_signal(signum)
        raise KeyboardInterrupt

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    try:
        for stage in plan['stages']:
            assert hashlib.sha256(plan_path.read_bytes()).hexdigest() == state['plan_sha256'], 'frozen plan changed during measurement'
            assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == plan['collector_revision'], 'collector revision changed during measurement'
            assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True), 'collector worktree changed during measurement'
            output = root / stage['directory']
            assert not output.exists(), 'Stage output must be new'
            arm = plan['arms'][stage['arm']]
            binaries = {name: Path(plan['binaries'][arm['engine'] if name == 'engine' else name]['path'])
                        for name in ('engine', 'gateway', 'bench')}
            metadata = collect_metadata(repo, binaries)
            assert metadata['git']['available'] and not metadata['git']['dirty'] and metadata['git']['head'] == plan['collector_revision']
            for name, path in binaries.items():
                recorded = plan['binaries'][arm['engine'] if name == 'engine' else name]
                assert metadata['binaries'][name]['available'] and metadata['binaries'][name]['sha256'] == recorded['sha256']
            write(root / (stage['directory'] + '-host-before.json'), metadata)
            command = [sys.executable, str(repo / 'benmark/experiment.py'), '--output', str(output),
                       '--modes', ','.join(stage['modes']), '--repeats', '1',
                       '--engine', str(binaries['engine']), '--gateway', str(binaries['gateway']),
                       '--bench', str(binaries['bench']), *plan['common_arguments']]
            if arm['max_data_bytes']:
                command.extend(['--max-data-bytes', str(arm['max_data_bytes'])])
            row = {'directory': stage['directory'], 'block': stage['block'], 'arm': stage['arm'],
                   'started_at': utc(), 'argv': command, 'returncode': None}
            state['stages'].append(row)
            write(root / 'execution.json', state)
            print(utc(), 'START', stage['directory'], flush=True)
            with (root / (stage['directory'] + '.log')).open('x') as log:
                signals['launching'] = True
                try:
                    process = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
                finally:
                    signals['launching'] = False
                if signals['pending'] is not None:
                    interrupted(signals['pending'], None)
                row['returncode'] = process.wait()
            process = None
            row['finished_at'] = utc()
            write(root / 'execution.json', state)
            print(utc(), 'END', stage['directory'], 'exit', row['returncode'], flush=True)
        state['status'] = 'complete'
    except BaseException as error:
        signals['cleaning'] = True
        state['status'] = 'interrupted' if isinstance(error, KeyboardInterrupt) else 'failed'
        state['error'] = repr(error)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=50)
            except subprocess.TimeoutExpired:
                # The experiment owns child cleanup; preserve its still-live PID
                # for diagnosis rather than launching a replacement run.
                state['cleanup_pending_pid'] = process.pid
        raise
    finally:
        state['finished_at'] = utc()
        write(root / 'execution.json', state)
    return int(any(row['returncode'] for row in state['stages']))


if __name__ == '__main__':
    sys.exit(main())
