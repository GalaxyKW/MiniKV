#!/usr/bin/env python3
"""Execute exactly one next stage of a frozen MiniKV comparison on Linux."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time


PROTOCOL = "single-stage-v1"
MODULES = ("benmark/experiment.py", "benmark/experiment_support.py", "benmark/summarize.py",
           "benmark/snapshot_report.py", "benmark/process_guard.py")
ROLES = ("engine", "gateway", "bench")
BINARY_KEYS = ("engine-A", "engine-B", "gateway", "bench")


class Refused(RuntimeError):
    pass


class Interrupted(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise Refused(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temporary = path.with_name(path.name + "." + str(os.getpid()) + ".tmp")
    try:
        with temporary.open("x") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(path)
        descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        if temporary.exists():
            temporary.unlink()


def process_identity(pid):
    directory = Path("/proc") / str(pid)
    first = (directory / "stat").read_text()
    fields = first[first.rfind(")") + 2:].split()
    identity = {"pid": pid, "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
                "starttime_ticks": int(fields[19]), "ppid": int(fields[1]), "state": fields[0],
                "exe": os.readlink(directory / "exe"),
                "cmdline": [word.decode("utf-8", "surrogateescape")
                            for word in (directory / "cmdline").read_bytes().split(b"\0") if word],
                "observed_at": utc()}
    final = (directory / "stat").read_text()
    final_fields = final[final.rfind(")") + 2:].split()
    require(int(final_fields[19]) == identity["starttime_ticks"], "PID changed while reading identity")
    return identity


def same_process(first, last):
    return all(first[key] == last[key] for key in ("pid", "boot_id", "starttime_ticks"))


def under(path, root):
    try:
        Path(path).relative_to(root)
        return True
    except (ValueError, TypeError):
        return False


def scan_private(root):
    """Inspect actual live processes, including a launch not yet in a ledger.

    Zombies are already stopped and cannot serve requests. Their executable and
    cmdline have disappeared; direct children are separately reaped with wait().
    A contending controller is excluded: the permanent flock serializes it.
    """
    found = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit() or int(directory.name) == os.getpid():
            continue
        try:
            item = process_identity(int(directory.name))
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            try:
                require(directory.stat().st_uid != os.getuid(), "cannot inspect an owned process: " + directory.name)
            except FileNotFoundError:
                pass
            continue
        if item["state"] == "Z":
            continue
        executable = item["exe"].removesuffix(" (deleted)")
        arguments = item["cmdline"]
        private_executable = under(executable, root)
        # Scripts have a shared Python executable. Match the actual collector's
        # script and private output, or a guard's private target executable.
        private_target = any(under(word, root) and ("/binaries/" in word or "/frozen/" in word)
                             for word in arguments if word.startswith("/"))
        private_runner = any(word.endswith("/benmark/experiment.py") for word in arguments)
        if private_runner:
            private_runner = "--output" in arguments and arguments.index("--output") + 1 < len(arguments)
            if private_runner:
                private_runner = under(arguments[arguments.index("--output") + 1], root)
        if private_executable or private_target or private_runner:
            found.append(item)
    return found


def git(repo, *arguments):
    environment = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(repo), *arguments],
                                   env=environment, text=True, timeout=10).strip()


def validate_sources(root, repo, plan, frozen_digest):
    require(sha(root / "plan.json") == frozen_digest, "frozen plan changed")
    require(plan.get("execution_protocol") == PROTOCOL, "plan must declare single-stage-v1")
    require(plan.get("policies", {}).get("stop_after_failed_stage") is True,
            "plan must prohibit continuation after an unsuccessful stage")
    require(re.fullmatch(r"[0-9a-f]{40}", plan.get("collector_revision", "")), "collector revision is not frozen")
    require(git(repo, "rev-parse", "HEAD") == plan["collector_revision"], "collector revision changed")
    require(not git(repo, "status", "--porcelain", "--untracked-files=all"), "collector worktree is not clean")
    require(set(plan["collector_files_sha256"]) == set(MODULES), "plan must freeze five collector modules")
    for name in MODULES:
        require(sha(repo / name) == plan["collector_files_sha256"][name], "collector module changed: " + name)
    require(Path(__file__).resolve() == root / "run_plan.py", "controller must be the copy in this experiment root")
    require(sha(root / "run_plan.py") == plan["driver_sha256"], "controller hash changed")
    require(set(plan["binaries"]) == set(BINARY_KEYS), "plan must freeze four executable files")
    for name in BINARY_KEYS:
        binary = root / "frozen" / name
        require(plan["binaries"][name]["path"] == str(binary), "binary is outside the new private frozen directory")
        require(binary.is_file() and os.access(binary, os.X_OK), "frozen binary is not executable: " + name)
        require(sha(binary) == plan["binaries"][name]["sha256"], "frozen binary changed: " + name)


def cases_for(stage, snapshot_ms):
    return ["r01-{}-snapshot-{}".format(mode, "on" if interval else "off")
            for mode in stage["modes"] for interval in (0, snapshot_ms)]


def verify_finished(root, stage, record, snapshot_ms):
    require(record.get("returncode") == 0 and type(record.get("returncode")) is int
            and record.get("finished_at") and not record.get("errors"), "earlier stage did not finish successfully")
    cleanup = record.get("cleanup", {})
    require(cleanup.get("status") == "verified_absent" and cleanup.get("live_processes") == [],
            "earlier stage lacks confirmed cleanup")
    index = read(root / stage["directory"] / "index.json")
    expected = cases_for(stage, snapshot_ms)
    require(index.get("status") == "complete" and [item["name"] for item in index["runs"]] == expected,
            "earlier stage index is not a complete ordered four-run stage")
    for case, recorded in zip(expected, index["runs"]):
        result = read(root / stage["directory"] / case / "result.json")
        require(recorded == result and result.get("status") == "ok" and not result.get("errors"),
                "earlier stage contains a failed, unfinished, or contradictory round")
        for role in ROLES:
            process = result.get("processes", {}).get(role, {})
            require(type(process.get("pid")) is int and process["pid"] > 0
                    and type(process.get("returncode")) is int and process["returncode"] == 0
                    and process.get("forced") is False, "earlier stage process did not exit normally: " + role)


def select_stage(root, plan, requested, state, snapshot_ms):
    stages = plan["stages"]
    require(len(stages) == 12, "formal plan must contain twelve stages")
    names = [item["directory"] for item in stages]
    require(len(set(names)) == 12 and all(isinstance(name, str) and re.fullmatch(r"stage-[0-9]{2}-[ABC]", name)
                                        for name in names), "stage names must be unique private directory names")
    for item in stages:
        require(item["modes"] in (["throughput", "reliable"], ["reliable", "throughput"]), "each stage needs both WAL modes")
    require(state.get("execution_protocol") == PROTOCOL and state.get("status") == "running", "plan is complete or halted")
    recorded = state["stages"]
    require(isinstance(recorded, list) and len(recorded) < len(stages), "no unstarted stage remains")
    for stage, record in zip(stages, recorded):
        require(all(record.get(field) == stage[field] for field in ("directory", "block", "arm")), "execution order differs from plan")
        verify_finished(root, stage, record, snapshot_ms)
        # A persistent record does not establish that its controller is gone.
        for role in ("controller", "runner"):
            identity = record.get(role)
            require(isinstance(identity, dict), "earlier stage lacks " + role + " identity")
            try:
                current = process_identity(identity["pid"])
            except (FileNotFoundError, ProcessLookupError):
                continue
            require(not same_process(identity, current), "earlier " + role + " process is still alive")
    next_stage = stages[len(recorded)]
    require(requested == next_stage["directory"], "only the next unstarted stage may execute: " + next_stage["directory"])
    require(not (root / requested).exists() and not (root / (requested + ".log")).exists()
            and not (root / (requested + "-host-before.json")).exists(), "stage artifacts already exist; no replacement is allowed")
    return next_stage


def configuration(root, repo, plan, stage):
    arm = plan["arms"][stage["arm"]]
    binaries = {role: Path(plan["binaries"][arm["engine"] if role == "engine" else role]["path"]) for role in ROLES}
    command = [sys.executable, str(repo / "benmark/experiment.py"), "--output", str(root / stage["directory"]),
               "--modes", ",".join(stage["modes"]), "--repeats", "1"]
    for role in ROLES:
        command.extend(["--" + role, str(binaries[role])])
    command.extend(plan["common_arguments"])
    if arm["max_data_bytes"]:
        command.extend(["--max-data-bytes", str(arm["max_data_bytes"])])
    return binaries, command


def observe_runner(process, expected_commands, controller_pid):
    deadline = time.monotonic() + 5
    observed = None
    while time.monotonic() < deadline:
        try:
            current = process_identity(process.pid)
        except (FileNotFoundError, ProcessLookupError):
            if process.poll() is not None:
                break
            time.sleep(.005)
            continue
        require(current["ppid"] == controller_pid, "runner was unexpectedly reparented")
        if current["cmdline"] in expected_commands:
            if observed is not None:
                require(same_process(observed, current), "runner identity changed during launch")
            observed = current
            if current["cmdline"] == expected_commands[-1]:
                return current
        time.sleep(.005)
    require(observed is not None, "runner exited or stalled before its identity could be observed")
    return observed


def signal_verified(identity, signum):
    """A pidfd pins the target while /proc identity is checked for PID reuse."""
    descriptor = os.pidfd_open(identity["pid"], 0)
    try:
        current = process_identity(identity["pid"])
        require(same_process(identity, current) and current["exe"] == identity["exe"], "refusing to signal a changed process")
        signal.pidfd_send_signal(descriptor, signum)
    finally:
        os.close(descriptor)


def cleanup_private(root, actions, grace):
    # These are only exact private processes observed by /proc; never pkill by
    # a generic executable name. A PID disappearing during inspection is normal.
    for signum, timeout in ((signal.SIGTERM, grace), (signal.SIGKILL, 5)):
        live = scan_private(root)
        if not live:
            break
        for identity in live:
            try:
                signal_verified(identity, signum)
                actions.append({"signal": signal.Signals(signum).name, "target": identity, "sent_at": utc()})
            except (FileNotFoundError, ProcessLookupError):
                continue
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and scan_private(root):
            time.sleep(.05)
    live = scan_private(root)
    return {"status": "pending" if live else "verified_absent", "checked_at": utc(),
            "scope": "no live private executable or collector processes; zombies are already stopped",
            "live_processes": live, "actions": actions}


def execute(root, repo, requested, lock_fd):
    plan = read(root / "plan.json")
    frozen_digest = sha(root / "plan.json")
    validate_sources(root, repo, plan, frozen_digest)
    options = dict(zip(plan["common_arguments"][::2], plan["common_arguments"][1::2]))
    snapshot_ms = int(options.get("--snapshot-ms", "1000"))
    grace = 3 * float(options.get("--shutdown-timeout", "15")) + 5
    stage_timeout = 4 * (float(options.get("--run-timeout", "120"))
                         + 2 * float(options.get("--startup-timeout", "10"))
                         + float(options.get("--settle-timeout", "10")) + grace) + 10
    require(snapshot_ms > 0 and math.isfinite(grace) and grace > 0
            and math.isfinite(stage_timeout) and stage_timeout > grace,
            "plan must provide finite positive snapshot and timeout settings")
    state_path = root / "execution.json"
    if state_path.exists():
        state = read(state_path)
        require(state.get("plan_sha256") == frozen_digest, "execution belongs to another plan")
    else:
        state = {"execution_protocol": PROTOCOL, "plan_sha256": frozen_digest,
                 "started_at": utc(), "status": "running", "stages": []}
    stage = select_stage(root, plan, requested, state, snapshot_ms)
    live = scan_private(root)
    require(not live, "private experiment processes are still alive: " + json.dumps(live))
    binaries, command = configuration(root, repo, plan, stage)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(repo / "benmark"))
    from experiment_support import collect_metadata
    metadata = collect_metadata(repo, binaries)
    require(metadata["git"]["available"] and metadata["git"]["head"] == plan["collector_revision"]
            and metadata["git"]["dirty"] is False, "host metadata cannot confirm the frozen collector")
    for role in ROLES:
        key = plan["arms"][stage["arm"]]["engine"] if role == "engine" else role
        require(metadata["binaries"][role]["available"] and metadata["binaries"][role]["sha256"] == plan["binaries"][key]["sha256"],
                "host metadata cannot confirm frozen executable: " + role)
    controller = process_identity(os.getpid())
    prefix = [sys.executable, "-I", "-S", str(repo / "benmark/process_guard.py"), str(os.getpid())]
    lock_stat = os.fstat(lock_fd)
    row = {"directory": stage["directory"], "block": stage["block"], "arm": stage["arm"],
           "started_at": utc(), "finished_at": None, "argv": command, "returncode": None, "errors": [],
           "controller": controller, "runner": None,
           "launcher": {"parent_pid": os.getpid(), "argv_prefix": prefix},
           "launcher_sha256": plan["collector_files_sha256"]["benmark/process_guard.py"],
           "lock": {"path": str(root / "execution.lock"), "device": lock_stat.st_dev, "inode": lock_stat.st_ino},
           "cleanup": {"status": "pending", "checked_at": None, "live_processes": [], "actions": []},
           "termination_grace_seconds": grace, "stage_timeout_seconds": stage_timeout}
    # This durable append is the unique stage claim. A lost controller leaves
    # an unfinished claim, which later invocations must never retry or skip.
    state["stages"].append(row)
    write(state_path, state)
    process = None
    pending = {"signal": None}
    actions = []

    def interrupted(signum, frame):
        # Do not throw between Popen returning and handle registration. The
        # polling loop observes the signal only after ownership is established.
        pending["signal"] = pending["signal"] or signum

    previous_handlers = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)}
    try:
        write(root / (requested + "-host-before.json"), metadata)
        validate_sources(root, repo, plan, frozen_digest)
        if pending["signal"] is not None:
            raise Interrupted(signal.Signals(pending["signal"]).name)
        print(utc(), "START", requested, flush=True)
        with (root / (requested + ".log")).open("x") as log:
            process = subprocess.Popen(prefix + command, cwd=repo, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                       pass_fds=(lock_fd,))
            row["runner"] = observe_runner(process, [prefix + command, command], os.getpid())
            write(state_path, state)
            deadline = time.monotonic() + stage_timeout
            while True:
                if pending["signal"] is not None:
                    raise Interrupted(signal.Signals(pending["signal"]).name)
                require(time.monotonic() < deadline, "stage exceeded its bounded total deadline")
                try:
                    row["returncode"] = process.wait(timeout=.2)
                    break
                except subprocess.TimeoutExpired:
                    continue
        require(row["returncode"] == 0, "runner exited with status " + str(row["returncode"]))
    except BaseException as error:
        row["errors"].append(type(error).__name__ + ": " + str(error))
        state["status"] = "interrupted" if isinstance(error, (Interrupted, KeyboardInterrupt)) else "failed"
        if process is not None:
            if process.poll() is None:
                process.terminate()
                actions.append({"role": "runner", "pid": process.pid, "signal": "SIGTERM", "sent_at": utc()})
                try:
                    row["returncode"] = process.wait(timeout=grace)
                except subprocess.TimeoutExpired:
                    process.kill()
                    actions.append({"role": "runner", "pid": process.pid, "signal": "SIGKILL", "sent_at": utc()})
                    try:
                        row["returncode"] = process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        row["errors"].append("runner remains alive after SIGKILL")
            else:
                row["returncode"] = process.wait()
    finally:
        try:
            try:
                if scan_private(root) and not row["errors"]:
                    row["errors"].append("runner exited leaving live private processes")
                    state["status"] = "failed"
                row["cleanup"] = cleanup_private(root, actions, grace)
            except BaseException as error:
                row["errors"].append("cleanup failed: " + type(error).__name__ + ": " + str(error))
                row["cleanup"] = {"status": "pending", "checked_at": utc(),
                                  "live_processes": None, "actions": actions}
                state["status"] = "failed"
            if row["cleanup"]["status"] != "verified_absent":
                row["errors"].append("private processes remain after cleanup")
                state["status"] = "failed"
            row["finished_at"] = utc()
            if not row["errors"]:
                try:
                    verify_finished(root, stage, row, snapshot_ms)
                    validate_sources(root, repo, plan, frozen_digest)
                except BaseException as error:
                    row["errors"].append(type(error).__name__ + ": " + str(error))
                    state["status"] = "failed"
            if pending["signal"] is not None:
                state["status"] = "interrupted"
                if not row["errors"]:
                    row["errors"].append("signal received during cleanup: " + signal.Signals(pending["signal"]).name)
            if not row["errors"]:
                state["status"] = "complete" if len(state["stages"]) == len(plan["stages"]) else "running"
            if state["status"] != "running":
                state["finished_at"] = utc()
            write(state_path, state)
        finally:
            for sig, handler in previous_handlers.items():
                signal.signal(sig, handler)
    print(utc(), "END", requested, "exit", row["returncode"], "state", state["status"], flush=True)
    return 0 if not row["errors"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()
    root, repo = args.root.resolve(), args.repository.resolve()
    require(sys.platform == "linux" and root.is_dir(), "an existing private Linux experiment root is required")
    require(hasattr(os, "pidfd_open") and hasattr(signal, "pidfd_send_signal"), "identity-safe cleanup requires pidfd support")
    descriptor = os.open(root / "execution.lock", os.O_CREAT | os.O_RDWR | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    try:
        require(stat.S_ISREG(os.fstat(descriptor).st_mode), "execution lock is not a regular file")
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        named, opened = (root / "execution.lock").stat(), os.fstat(descriptor)
        require((named.st_dev, named.st_ino) == (opened.st_dev, opened.st_ino), "execution lock inode changed")
        return execute(root, repo, args.stage, descriptor)
    finally:
        # No LOCK_UN: the runner shares this open file description. Closing our
        # copy leaves its lease held if it still survives an abnormal exit.
        os.close(descriptor)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (Refused, OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print("stage controller: " + str(error), file=sys.stderr, flush=True)
        sys.exit(2)
