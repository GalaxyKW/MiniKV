#!/usr/bin/env python3
"""Offline-only mutation checks over explicitly synthetic protocol fixtures."""
import contextlib
import hashlib
import json
from pathlib import Path
import shutil
import sys
import check_fixture as fixture

ROOT = fixture.ROOT
WORK = fixture.WORK
STAGE = ROOT / 'stage-01-A'
CHECKS = []
OPEN_ATTEMPTS = []

def forbid_old_reads(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes)):
        raw = args[0].decode() if isinstance(args[0], bytes) else args[0]
        path = str(Path(raw).absolute())
        if path == fixture.OLD or path.startswith(fixture.OLD + '/'):
            OPEN_ATTEMPTS.append(path)
            raise AssertionError('auditor opened historical absolute root: ' + path)

@contextlib.contextmanager
def restore(paths):
    saved = {path: path.read_bytes() if path.exists() else None for path in paths}
    try:
        yield
    finally:
        for path, content in saved.items():
            if content is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(content)

def run(name, eligible, *, root=ROOT, expected_error=None, expected_official_valid=33, check=None):
    code, result = fixture.analyze(root)
    assert code == 1, (name, code)
    counts = result['counts']
    assert counts['planned_rounds'] == 48, (name, counts)
    assert counts['eligible_rounds'] == eligible, (name, counts)
    assert counts['official_status']['valid'] == expected_official_valid, (name, counts)
    assert counts['official_status']['incomplete'] == 1 and counts['official_status']['missing'] == 14, (name, counts)
    assert counts['inconclusive_comparisons'] == 8, (name, counts)
    assert all(group['classification'] == 'inconclusive' and not group['triggered_metrics']
               and group['engine_rss_diagnostic'] == 'inconclusive' for group in result['comparisons']), name
    if expected_error:
        errors = result['errors'] + [error for stage in result['stages'] for error in stage['errors']]
        errors += [error for row in result['rounds'] for error in row['errors']]
        assert any(expected_error in error for error in errors), (name, errors)
    if check:
        check(result)
    record = {'check': name, 'passed': True, 'exit': code, 'counts': counts,
              'execution_complete': result['execution']['complete'], 'fixture': str(root)}
    CHECKS.append(record)
    print(json.dumps(record), flush=True)
    return result

def edit(path, fn):
    body = fixture.read(path)
    fn(body)
    fixture.save(path, body)

def main():
    # Refresh the private reader snapshot only; every analyzed root is private.
    shutil.copyfile(fixture.SOURCE / 'audit_capacity.py', WORK / 'audit_under_test.py')
    sys.addaudithook(forbid_old_reads)
    run('synthetic_interrupted_baseline', 33)

    plan_path = ROOT / 'plan.json'
    with restore([plan_path]):
        edit(plan_path, lambda plan: plan.pop('execution_protocol'))
        try:
            fixture.analyze()
        except ValueError as error:
            assert 'execution protocol' in str(error), error
            CHECKS.append({'check': 'missing_frozen_execution_protocol', 'passed': True,
                           'raised': type(error).__name__, 'message': str(error), 'fixture': str(ROOT)})
        else:
            raise AssertionError('missing frozen execution protocol was accepted')

    execution_path = ROOT / 'execution.json'
    with restore([execution_path]):
        edit(execution_path, lambda execution: execution.pop('execution_protocol'))
        run('missing_recorded_execution_protocol', 0, expected_error='execution protocol differs')

    manifest_path = STAGE / 'manifest.json'
    commands_paths = list(STAGE.glob('r*/commands.json'))
    with restore([manifest_path, *commands_paths]):
        edit(manifest_path, lambda manifest: manifest.pop('process_guard'))
        for path in commands_paths:
            edit(path, lambda commands: commands.pop('launcher'))
        run('guard_and_launcher_removed_together', 29, expected_error='required process guard metadata')

    helper_path = STAGE / 'process_guard.py'
    with restore([manifest_path, helper_path]):
        payload = b'# Synthetic incorrect helper: never executed.\nraise SystemExit(125)\n'
        helper_path.write_bytes(payload)
        replacement = hashlib.sha256(payload).hexdigest()
        edit(manifest_path, lambda manifest: manifest['process_guard'].update(sha256=replacement))
        run('self_consistent_replacement_helper', 29, expected_error='differs from frozen collector helper')

    path = STAGE / 'r01-throughput-snapshot-off/commands.json'
    with restore([path]):
        def alter_parent(commands):
            commands['launcher']['parent_pid'] += 100
            commands['launcher']['argv_prefix'][-1] = str(commands['launcher']['parent_pid'])
        edit(path, alter_parent)
        run('self_consistent_inner_launcher_wrong_parent', 32, expected_error='differs from observed runner PID')

    moved = WORK / 'relocated-without-helper-copies'
    shutil.copytree(ROOT, moved)
    for helper in moved.glob('stage-*/process_guard.py'):
        helper.unlink()
    def recorded_only(result):
        present = [stage for stage in result['stages'] if stage['official_counts'] is not None]
        assert len(present) == 9
        assert all(stage['process_guard_verification'] == 'recorded_hashes_only' for stage in present)
        assert all(any('Process guard copy is absent' in warning for warning in stage['warnings']) for stage in present)
    run('relocated_missing_copies_uses_recorded_guard_hash', 33, root=moved, check=recorded_only)
    missing_manifest = moved / 'stage-01-A/manifest.json'
    missing_commands = list((moved / 'stage-01-A').glob('r*/commands.json'))
    with restore([missing_manifest, *missing_commands]):
        edit(missing_manifest, lambda manifest: manifest.pop('process_guard'))
        for path in missing_commands:
            edit(path, lambda commands: commands.pop('launcher'))
        run('relocated_missing_metadata_is_not_recorded_hash_fallback', 29, root=moved,
            expected_error='required process guard metadata')

    with restore([execution_path]):
        edit(execution_path, lambda execution: execution['stages'][-1].update(runner=None))
        result = run('unfinished_final_claim_has_no_runner_identity', 32, expected_error='recorded runner identity')
        assert all(row['eligible'] for row in result['rounds'][:32])

    with restore([execution_path]):
        edit(execution_path, lambda execution: execution['stages'][-1].update(errors=['synthetic controller interruption']))
        result = run('final_controller_error_preserves_valid_round_prefix', 33)
        assert any('synthetic controller interruption' in warning for warning in result['stages'][8]['warnings'])

    with restore([execution_path]):
        def no_cleanup(execution):
            execution['status'] = 'failed'
            execution['stages'][-1].update(returncode=143, finished_at='2026-09-22T11:27:34.041279+00:00')
            execution['stages'][-1].pop('cleanup', None)
        edit(execution_path, no_cleanup)
        result = run('final_stage_missing_cleanup_preserves_valid_round_prefix', 33)
        assert any('verified process cleanup' in warning for warning in result['stages'][8]['warnings'])
        assert all(row['eligible'] for row in result['rounds'][:33])

    # Restore the visible baseline analysis after all mutations were reverted.
    fixture.analyze(ROOT)
    assert not OPEN_ATTEMPTS, OPEN_ATTEMPTS
    validation = {'synthetic_fixture': True, 'notice': 'Only offline private fixture mutations; no new measurements.',
                  'private_root': str(WORK), 'collector': str(fixture.COLLECTOR),
                  'collector_revision': fixture.REVISION, 'auditor_sha256': fixture.sha(WORK / 'audit_under_test.py'),
                  'current_source_auditor_sha256': fixture.sha(fixture.SOURCE / 'audit_capacity.py'),
                  'historical_absolute_root_open_attempts': OPEN_ATTEMPTS,
                  'formal_execution_or_analysis_written': False, 'checks': CHECKS}
    fixture.save(WORK / 'validation.json', validation)
    print(json.dumps({'passed_checks': len(CHECKS), 'validation': str(WORK / 'validation.json')}), flush=True)

if __name__ == '__main__':
    main()
