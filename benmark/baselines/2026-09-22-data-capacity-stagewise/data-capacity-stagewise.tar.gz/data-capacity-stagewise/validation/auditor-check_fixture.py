#!/usr/bin/env python3
"""Synthetic protocol fixtures; archived measurements are not new experiments."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
SOURCE = Path('/mnt/nvme/minikv-review/capacity-stagewise-iobxnqbx')
COLLECTOR = SOURCE / 'collector'
OLD = '/mnt/nvme/minikv-review/data-capacity-comparison-Q5TeKg'
ROOT = WORK / 'synthetic'
REVISION = 'bc7e031a962ff44367a160a5fc5adcda83ac1893'
FILES = ('experiment.py', 'summarize.py', 'experiment_support.py', 'snapshot_report.py', 'process_guard.py')

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def build():
    ROOT.mkdir()
    archive = Path('/mnt/nvme/MiniKV/benmark/baselines/2026-09-22-data-capacity/data-capacity.tar.gz')
    with tarfile.open(archive) as stream:
        for member in stream.getmembers():
            parts = Path(member.name).parts
            assert parts[0] == 'data-capacity' and '..' not in parts and member.isfile()
            destination = ROOT.joinpath(*parts[1:])
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(stream.extractfile(member).read())
    shutil.copyfile(SOURCE / 'run_plan.py', ROOT / 'run_plan.py')
    shutil.copyfile(SOURCE / 'audit_capacity.py', WORK / 'audit_under_test.py')
    plan = read(ROOT / 'plan.json')
    plan['execution_protocol'] = 'single-stage-v1'
    plan['collector_revision'] = REVISION
    plan['collector_files_sha256'] = {'benmark/' + name: sha(COLLECTOR / 'benmark' / name) for name in FILES}
    plan['driver_sha256'] = sha(ROOT / 'run_plan.py')
    plan['policies']['stop_after_failed_stage'] = True
    plan['synthetic_fixture'] = True
    save(ROOT / 'plan.json', plan)
    execution = read(ROOT / 'execution.json')
    execution['execution_protocol'] = plan['execution_protocol']
    execution['plan_sha256'] = sha(ROOT / 'plan.json')
    execution['synthetic_fixture'] = True
    helper = (COLLECTOR / 'benmark/process_guard.py').read_bytes()
    for number, record in enumerate(execution['stages']):
        controller_pid = 700000 + number * 2
        runner_pid = controller_pid + 1
        command = record['argv']
        def identity(pid, ppid, cmdline):
            return {'pid': pid, 'ppid': ppid, 'starttime_ticks': 100000 + pid,
                    'boot_id': '00000000-0000-0000-0000-000000000001', 'exe': '/usr/bin/python3.12',
                    'cmdline': cmdline, 'state': 'S', 'observed_at': record['started_at']}
        record['controller'] = identity(controller_pid, 1, [command[0], OLD + '/run_plan.py', OLD])
        record['runner'] = identity(runner_pid, controller_pid, command)
        record['launcher'] = {'parent_pid': controller_pid, 'argv_prefix':
                              [command[0], '-I', '-S', str(Path(command[1]).with_name('process_guard.py')), str(controller_pid)]}
        record['launcher_sha256'] = plan['collector_files_sha256']['benmark/process_guard.py']
        record['errors'] = []
        if record.get('finished_at'):
            record['cleanup'] = {'status': 'verified_absent', 'live_processes': [], 'actions': [],
                                 'checked_at': record['finished_at']}
        stage = ROOT / record['directory']
        manifest = read(stage / 'manifest.json')
        manifest['metadata']['git']['head'] = REVISION
        guard = {'protocol': 'linux-pdeathsig-v1', 'path': manifest['arguments']['output'] + '/process_guard.py',
                 'sha256': record['launcher_sha256'], 'python': command[0], 'signal': 'SIGKILL'}
        manifest['process_guard'] = guard
        save(stage / 'manifest.json', manifest)
        (stage / 'process_guard.py').write_bytes(helper)
        host = ROOT / (record['directory'] + '-host-before.json')
        metadata = read(host)
        metadata['git']['head'] = REVISION
        save(host, metadata)
        for path in stage.glob('r*/commands.json'):
            commands = read(path)
            commands['launcher'] = {'parent_pid': runner_pid, 'argv_prefix':
                                   [guard['python'], '-I', '-S', guard['path'], str(runner_pid)]}
            save(path, commands)
    save(ROOT / 'execution.json', execution)
    save(ROOT / 'SYNTHETIC_FIXTURE.json', {'notice': 'Synthetic protocol metadata over historical raw measurements; never a fresh campaign.',
                                         'source_archive': str(archive), 'auditor_sha256': sha(WORK / 'audit_under_test.py')})

def forbid_old_reads(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes)):
        path = str(Path(args[0].decode() if isinstance(args[0], bytes) else args[0]).absolute())
        if path == OLD or path.startswith(OLD + '/'):
            raise AssertionError('auditor opened the historical absolute root: ' + path)

def analyze(root=ROOT):
    spec = importlib.util.spec_from_file_location('private_capacity_auditor', WORK / 'audit_under_test.py')
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    previous = sys.argv
    try:
        sys.argv = [str(WORK / 'audit_under_test.py'), str(root), '--repository', str(COLLECTOR)]
        with contextlib.redirect_stdout(io.StringIO()):
            code = audit.main()
    finally:
        sys.argv = previous
    result = read(root / 'analysis.json')
    return code, result

if __name__ == '__main__':
    build()
    sys.addaudithook(forbid_old_reads)
    code, result = analyze()
    print(json.dumps({'returncode': code, 'counts': result['counts'], 'errors': result['errors'],
                      'stage_errors': {s['directory']:s['errors'] for s in result['stages'] if s['errors']}}, indent=2))
    assert result['counts']['planned_rounds'] == 48
    assert result['counts']['eligible_rounds'] == 33
    assert result['counts']['official_status']['incomplete'] == 1
    assert result['counts']['official_status']['missing'] == 14
    assert result['counts']['inconclusive_comparisons'] == 8
