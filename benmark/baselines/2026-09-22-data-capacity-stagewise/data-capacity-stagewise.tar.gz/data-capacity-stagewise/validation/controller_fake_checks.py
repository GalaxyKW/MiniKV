#!/usr/bin/env python3
"""Isolated controller checks: fake services only; never formal experiment data."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time

SOURCE = Path('/mnt/nvme/minikv-review/capacity-stagewise-iobxnqbx/run_plan.py')
REPO = Path('/mnt/nvme/MiniKV')
BASE = Path(tempfile.mkdtemp(prefix='controller-fake-', dir='/mnt/nvme/minikv-review'))
COLLECTOR = BASE / 'collector'
COLLECTOR.mkdir()
(COLLECTOR / 'benmark').mkdir()
FAKE = r'''import json, os, signal, subprocess, sys, time
from pathlib import Path
args = dict(zip(sys.argv[1::2], sys.argv[2::2]))
output = Path(args['--output'])
output.mkdir()
behavior = os.environ.get('FAKE_BEHAVIOR', 'success')
guard = str(Path(__file__).with_name('process_guard.py'))
def spawn(role, delay):
    return subprocess.Popen([sys.executable, '-I', '-S', guard, str(os.getpid()), args['--'+role], str(delay)])
def save(path, value):
    path.write_text(json.dumps(value))
if behavior in ('hold', 'ignoreterm'):
    child = spawn('engine', 60)
    save(output / 'fixture-child.json', {'pid': child.pid})
    if behavior == 'ignoreterm':
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
    else:
        def stopped(signum, frame):
            child.terminate()
            child.wait(timeout=3)
            sys.exit(143)
        signal.signal(signal.SIGTERM, stopped)
    time.sleep(60)
    sys.exit(0)
time.sleep(.15)
if behavior == 'failure':
    sys.exit(7)
runs = []
for mode in args['--modes'].split(','):
    for snapshot in ('off', 'on'):
        name = 'r01-'+mode+'-snapshot-'+snapshot
        directory = output / name
        directory.mkdir()
        processes = {}
        for role in ('engine', 'gateway', 'bench'):
            child = spawn(role, .005)
            processes[role] = {'pid': child.pid, 'returncode': child.wait(), 'forced': False}
        if behavior == 'forced':
            processes['engine']['forced'] = True
        result = {'name': name, 'status': 'ok', 'errors': [], 'processes': processes}
        save(directory / 'result.json', result)
        runs.append(result)
save(output / 'index.json', {'status': 'complete', 'runs': runs})
if behavior == 'orphan':
    child = subprocess.Popen([args['--engine'], '60'], start_new_session=True)
    save(output / 'fixture-child.json', {'pid': child.pid})
'''
(COLLECTOR / 'benmark/experiment.py').write_text(FAKE)
for name in ('experiment_support.py', 'process_guard.py'):
    shutil.copyfile(REPO / 'benmark' / name, COLLECTOR / 'benmark' / name)
for name in ('summarize.py', 'snapshot_report.py'):
    (COLLECTOR / 'benmark' / name).write_text('# inert frozen test module\n')
(COLLECTOR / '.gitignore').write_text('__pycache__/\n')
subprocess.run(['git', 'init', '-q', str(COLLECTOR)], check=True)
subprocess.run(['git', '-C', str(COLLECTOR), 'add', '.'], check=True)
subprocess.run(['git', '-C', str(COLLECTOR), '-c', 'user.name=Controller Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'Isolated fake collector'], check=True)
REV = subprocess.check_output(['git','-C',str(COLLECTOR),'rev-parse','HEAD'],text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def fixture(name):
    root = BASE / name
    root.mkdir()
    shutil.copyfile(SOURCE, root / 'run_plan.py')
    (root / 'frozen').mkdir()
    binaries = {}
    for key in ('engine-A','engine-B','gateway','bench'):
        target = root / 'frozen' / key
        shutil.copyfile('/bin/sleep', target)
        target.chmod(0o755)
        binaries[key] = {'path':str(target),'sha256':sha(target)}
    stages=[]
    for block, order in enumerate(('ABC','CBA','BCA','ACB'),1):
        for arm in order:
            stages.append({'directory':'stage-%02d-%s'%(len(stages)+1,arm),'block':block,'arm':arm,'modes':['throughput','reliable'] if block%2 else ['reliable','throughput']})
    plan={'execution_protocol':'single-stage-v1','collector_revision':REV,'collector_files_sha256':{'benmark/'+name:sha(COLLECTOR/'benmark'/name) for name in ('experiment.py','experiment_support.py','summarize.py','snapshot_report.py','process_guard.py')},'driver_sha256':sha(root/'run_plan.py'),'binaries':binaries,'arms':{arm:{'engine':'engine-A' if arm=='A' else 'engine-B','max_data_bytes':131072 if arm=='C' else 0} for arm in 'ABC'},'stages':stages,'common_arguments':['--snapshot-ms','1000','--run-timeout','1','--startup-timeout','.1','--shutdown-timeout','.1','--settle-timeout','.1'],'policies':{'stop_after_failed_stage':True}}
    (root/'plan.json').write_text(json.dumps(plan))
    return root,plan

def command(root,stage):
    return [sys.executable,str(root/'run_plan.py'),str(root),'--repository',str(COLLECTOR),'--stage',stage]
def launch(root,stage='stage-01-A',behavior='success'):
    return subprocess.Popen(command(root,stage),env={**os.environ,'FAKE_BEHAVIOR':behavior},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def run(root,stage='stage-01-A',behavior='success',expected=0):
    p=launch(root,stage,behavior)
    output=p.communicate(timeout=20)[0]
    assert (p.returncode==0)==(expected==0),(root.name,p.returncode,output)
    return p.returncode,output

def data(root): return json.loads((root/'execution.json').read_text())
def identity(pid):
    directory=Path('/proc')/str(pid)
    text=(directory/'stat').read_text()
    fields=text[text.rfind(')')+2:].split()
    return {'pid':pid,'ppid':int(fields[1]),'starttime_ticks':int(fields[19]),
            'exe':os.readlink(directory/'exe'),
            'cmdline':[(v.decode()) for v in (directory/'cmdline').read_bytes().split(b'\0') if v]}

def wait_for(call,timeout=10):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:
            result=call()
            if result: return result
        except (FileNotFoundError,KeyError,IndexError,json.JSONDecodeError): pass
        time.sleep(.01)
    raise AssertionError('timed out waiting for fixture state')
def stopped(pid):
    try:
        text=(Path('/proc')/str(pid)/'stat').read_text()
        return text[text.rfind(')')+2:].split()[0]=='Z'
    except FileNotFoundError: return True
checks=[]
def passed(name,**extra):
    checks.append({'name':name,'status':'passed',**extra})
    print('PASS',name,flush=True)

# All 12 stages must advance one invocation at a time and retain the lock inode.
root,plan=fixture('happy')
run(root,'stage-02-B',expected=1)
assert not (root/'execution.json').exists()
passed('out-of-order first stage refused without claim')
lock_inode=(root/'execution.lock').stat().st_ino
for index,stage in enumerate(plan['stages']):
    run(root,stage['directory'])
    state=data(root)
    assert len(state['stages'])==index+1
    assert state['status']==('complete' if index==11 else 'running')
    assert state['stages'][-1]['cleanup']['status']=='verified_absent'
    assert (root/'execution.lock').stat().st_ino==lock_inode
    if index==0:
        before=(root/'execution.json').read_bytes()
        run(root,stage['directory'],expected=1)
        assert (root/'execution.json').read_bytes()==before
run(root,'stage-12-B',expected=1)
passed('12-stage progression, permanent lock inode, duplicate and completed-plan refusal')

for behavior in ('failure','forced','orphan'):
    root,_=fixture(behavior)
    run(root,behavior=behavior,expected=1)
    state=data(root)
    assert state['status']=='failed' and len(state['stages'])==1
    assert state['stages'][0]['errors']
    assert state['stages'][0]['cleanup']['status']=='verified_absent'
    if behavior=='orphan':
        child=json.loads((root/'stage-01-A/fixture-child.json').read_text())['pid']
        assert stopped(child)
    before=(root/'execution.json').read_bytes()
    run(root,'stage-02-B',expected=1)
    assert (root/'execution.json').read_bytes()==before
    passed('failed stage blocks advance: '+behavior)

# Hold a real runner and service while a second controller competes for the lock.
root,_=fixture('mutex-term')
process=launch(root,behavior='hold')
try:
    row=wait_for(lambda:data(root)['stages'][0] if data(root)['stages'][0]['runner'] else None)
    child=wait_for(lambda:json.loads((root/'stage-01-A/fixture-child.json').read_text())['pid'])
    runner=row['runner']['pid']
    fd_links=[]
    for fd in (Path('/proc')/str(runner)/'fd').iterdir():
        try:
            if os.readlink(fd)==str(root/'execution.lock'):
                fd_links.append({'fd':int(fd.name),'inode':fd.stat().st_ino})
        except FileNotFoundError: pass
    assert len(fd_links)==1 and fd_links[0]['inode']==(root/'execution.lock').stat().st_ino
    run(root,expected=1)
    assert len(data(root)['stages'])==1 and not stopped(runner) and not stopped(child)
    process.terminate()
    output=process.communicate(timeout=15)[0]
    assert process.returncode!=0 and stopped(runner) and stopped(child),output
    state=data(root)
    assert state['status']=='interrupted' and state['stages'][0]['cleanup']['status']=='verified_absent'
    assert state['stages'][0]['returncode']==143
    passed('mutual exclusion, actual inherited runner lock FD, TERM and wait cleanup',runner_pid=runner,child_pid=child,runner_lock_fd=fd_links)
finally:
    if process.poll() is None: process.kill(); process.wait()

# Kernel parent death must remove both levels even when no controller finally runs.
root,_=fixture('parent-death')
process=launch(root,behavior='hold')
try:
    row=wait_for(lambda:data(root)['stages'][0] if data(root)['stages'][0]['runner'] else None)
    child=wait_for(lambda:json.loads((root/'stage-01-A/fixture-child.json').read_text())['pid'])
    runner=row['runner']['pid']
    child_identity=wait_for(lambda:identity(child) if identity(child)['exe']==str(root/'frozen/engine-A') else None)
    runner_identity=identity(runner)
    assert runner_identity['ppid']==process.pid and child_identity['ppid']==runner
    assert not stopped(runner) and not stopped(child)
    assert any(os.readlink(fd)==str(root/'execution.lock') for fd in (Path('/proc')/str(runner)/'fd').iterdir())
    process.kill()
    process.communicate(timeout=5)
    wait_for(lambda:stopped(runner) and stopped(child))
    # Independently check the actual kernel lock has gone, not just state JSON.
    with (root/'execution.lock').open('r+') as stream:
        fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=(root/'execution.json').read_bytes()
    assert data(root)['stages'][0]['finished_at'] is None
    run(root,expected=1)
    run(root,'stage-02-B',expected=1)
    assert (root/'execution.json').read_bytes()==before
    passed('SIGKILL controller→runner→service chain, actual lock release, incomplete claim blocks retry/skip',controller_pid=process.pid,runner_identity=runner_identity,child_identity=child_identity)
finally:
    if process.poll() is None: process.kill(); process.wait()

root,_=fixture('kill-fallback')
process=launch(root,behavior='ignoreterm')
try:
    row=wait_for(lambda:data(root)['stages'][0] if data(root)['stages'][0]['runner'] else None)
    child=wait_for(lambda:json.loads((root/'stage-01-A/fixture-child.json').read_text())['pid'])
    time.sleep(.1)
    process.terminate()
    output=process.communicate(timeout=15)[0]
    state=data(root); row=state['stages'][0]
    assert process.returncode!=0 and row['returncode']==-signal.SIGKILL,output
    assert stopped(row['runner']['pid']) and stopped(child)
    assert row['cleanup']['status']=='verified_absent'
    assert [a['signal'] for a in row['cleanup']['actions']]==['SIGTERM','SIGKILL']
    passed('bounded TERM→KILL fallback and actual child cleanup')
finally:
    if process.poll() is None: process.kill(); process.wait()

for mutation in ('driver','binary','helper','dirty','head'):
    root,plan=fixture('tamper-'+mutation)
    if mutation=='driver':
        with (root/'run_plan.py').open('a') as f:f.write('\n# changed\n')
    elif mutation=='binary':
        with (root/'frozen/engine-B').open('ab') as f:f.write(b'changed')
    elif mutation=='helper':
        plan['collector_files_sha256']['benmark/process_guard.py']='0'*64
        (root/'plan.json').write_text(json.dumps(plan))
    elif mutation=='head':
        plan['collector_revision']='0'*40
        (root/'plan.json').write_text(json.dumps(plan))
    else: (COLLECTOR/'unexpected-untracked').write_text('dirty')
    try:
        run(root,expected=1)
        assert not (root/'execution.json').exists()
    finally:
        if mutation=='dirty': (COLLECTOR/'unexpected-untracked').unlink()
    passed('preclaim provenance refusal: '+mutation)

root,_=fixture('actual-leftover')
child=subprocess.Popen([str(root/'frozen/engine-A'),'30'])
try:
    run(root,expected=1)
    assert child.poll() is None and not (root/'execution.json').exists()
    passed('actual private executable blocks start without trusting absent state')
finally:
    child.terminate();child.wait()

result={'source':str(SOURCE),'source_sha256':sha(SOURCE),'fixture_root':str(BASE),'checks':checks,'count':len(checks),'formal_execution_created':(SOURCE.parent/'execution.json').exists()}
(BASE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
