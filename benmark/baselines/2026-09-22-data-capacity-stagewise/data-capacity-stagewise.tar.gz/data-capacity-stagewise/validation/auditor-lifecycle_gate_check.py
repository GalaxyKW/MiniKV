#!/usr/bin/env python3
"""Isolate lifecycle gating from sample-count gating without inventing raw runs."""
import contextlib
import importlib.util
import io
import sys
import check_fixture as fixture

sys.dont_write_bytecode = True
attempts = []

def guard(event, args):
    try:
        fixture.forbid_old_reads(event, args)
    except AssertionError:
        attempts.append(str(args[0]))
        raise

sys.addaudithook(guard)
spec = importlib.util.spec_from_file_location('lifecycle_probe_auditor', fixture.WORK / 'audit_under_test.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
original_ratios = audit.ratios
classifier_called = []

def qualified_classifier(rows, plan):
    pairs, groups = original_ratios(rows, plan)
    classifier_called.append(len(groups))
    # This boundary probe stubs only a classifier output. It neither creates
    # measured rounds nor claims the historical prefix has four eligible pairs.
    for group in groups:
        group.update(classification='investigate', triggered_metrics=['qps'], engine_rss_diagnostic='investigate')
    return pairs, groups

audit.ratios = qualified_classifier
paths = [fixture.ROOT / ('analysis.' + extension) for extension in ('json', 'csv')]
saved = {path: path.read_bytes() for path in paths}
previous = sys.argv
try:
    sys.argv = [str(fixture.WORK / 'audit_under_test.py'), str(fixture.ROOT), '--repository', str(fixture.COLLECTOR)]
    with contextlib.redirect_stdout(io.StringIO()):
        code = audit.main()
    result = fixture.read(fixture.ROOT / 'analysis.json')
finally:
    sys.argv = previous
    for path, data in saved.items():
        path.write_bytes(data)

assert classifier_called == [8], classifier_called
assert code == 1 and result['execution']['complete'] is False
assert result['counts']['inconclusive_comparisons'] == 8
assert all(group['classification'] == 'inconclusive' and group['triggered_metrics'] == []
           and group['engine_rss_diagnostic'] == 'inconclusive' and 'execution_warning' in group
           for group in result['comparisons'])
assert not attempts, attempts
path = fixture.WORK / 'validation.json'
validation = fixture.read(path)
validation['checks'].append({'check': 'incomplete_execution_overrides_metric_classifier_trigger', 'passed': True,
                             'kind': 'in-memory classifier-boundary probe; metric classifier output stubbed, no raw rounds invented',
                             'exit': code, 'counts': result['counts'], 'execution_complete': False,
                             'classifications_before_lifecycle_gate': ['investigate'] * 8,
                             'classifications_after_lifecycle_gate': ['inconclusive'] * 8,
                             'fixture': str(fixture.ROOT)})
fixture.save(path, validation)
print('PASS: incomplete execution overrides eight classifier triggers; validation now has %d checks' % len(validation['checks']))
